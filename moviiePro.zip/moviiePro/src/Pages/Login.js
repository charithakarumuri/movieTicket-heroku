import React from 'react';
import { useNavigate } from "react-router-dom";

const Login = () => {
    const navigate = useNavigate();
    return (
        <div className='d-flex justify-content-center'>
            <form className='mt-5'>
                <div className="mb-3">
                    {/* <label for="validationCustomUsername" className="form-label">Username</label> */}
                    <div className="input-group has-validation">
                        <span className="input-group-text" id="inputGroupPrepend">@</span>
                        <input type="text" class="form-control" placeholder='email' id="validationCustomUsername" aria-describedby="inputGroupPrepend" required />
                        <div className="invalid-feedback">
                            Please choose a username.
                        </div>
                    </div>

                </div>
                <div class="mb-3">
                    {/* <label for="exampleInputPassword1" class="form-label">Password</label> */}
                    <input type="password" placeholder='password' class="form-control" id="exampleInputPassword1" />
                </div>
                <button type="button" class="btn btn-info" onClick={() => navigate("/home")}>Login</button>
            </form>

        </div>
    )
}

export default Login
